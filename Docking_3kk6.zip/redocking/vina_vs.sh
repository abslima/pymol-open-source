#!/bin/bash
for f in *.pdbqt; do
    b=$(basename "$f" .pdbqt)
    echo "Processing ligand $b"
    vina --config conf.txt --ligand "$f" --out "${b}_out.pdbqt" --log "${b}_log.txt"
done
